#include "chloros.h"

#include <stdio.h>
#include <stdlib.h>

static bool enable_preemption = false;

void worker(void* arg) {
    int num = *((int*) arg);

    for (int i = 0; i < 10; i++) {
        printf("hello from worker %d\n", num);
        if (!enable_preemption) {
            thread_yield();
        }
    }

    free(arg);
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        enable_preemption = true;
    }
    thread_init_int(enable_preemption);
    for (int i = 0; i < 4; i++) {
        int* num = malloc(sizeof(int));
        *num = i;
        thread_spawn(&worker, num);
    }

    thread_wait();

    return 0;
}
